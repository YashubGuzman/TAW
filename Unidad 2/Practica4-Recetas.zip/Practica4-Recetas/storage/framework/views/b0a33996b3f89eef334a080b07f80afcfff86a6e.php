<h1>Recetas </h1>

<?php $__currentLoopData = $recetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($receta); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<h1>Categorias </h1>

<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($categoria); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\Tecnologias Web\Unidad 2\recetas\resources\views/recetas/index.blade.php ENDPATH**/ ?>